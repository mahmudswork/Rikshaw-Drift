// Optional Firebase helper - client-side (not required if using inline code)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};
function initFirebase(){ firebase.initializeApp(firebaseConfig); return firebase.firestore(); }
